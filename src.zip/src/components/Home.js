import React from 'react'

function Home() {
  return (
    <h1>Greetings of the Day</h1>
  )
}

export default Home